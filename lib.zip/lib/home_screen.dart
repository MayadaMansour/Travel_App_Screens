import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Padding(
          padding: const EdgeInsets.only(bottom: 0.2),
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(right: 300),
                child: const Text(
                  "Setting",
                  style:
                      TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(height: 10,),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Container(
                          padding: EdgeInsets.all(2), // Border width
                          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(50)),
                          child: ClipRRect(
                            borderRadius:  BorderRadius.circular(50),
                            child: SizedBox.fromSize(
                              size: Size.fromRadius(48), // Image radius
                              child: Image.network('https://www.rd.com/wp-content/uploads/2019/11/cat-10-e1573844975155.jpg?fit=700,700', fit: BoxFit.cover),
                            ),
                          ),

                    ),
                  ),
                  SizedBox(width: 30,),
                  Column(
                    children: [
                      Text(" Hello",style: TextStyle(color: Colors.white,fontSize: 18,fontWeight: FontWeight.bold),),
                      Text("Mayada Mansour",style: TextStyle(color: Colors.white,fontSize: 18),),

                    ],
                  ),
                  SizedBox(width: 30,),
                  IconButton(onPressed: (){}, icon: Icon(Icons.edit,color: Colors.white,))
                ],
              ),
            ],
          ),
        ),
        titleSpacing: 00.0,
        toolbarHeight: 150.2,
        toolbarOpacity: 0.8,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              bottomRight: Radius.circular(35),
              bottomLeft: Radius.circular(35)),
        ),
        elevation: 0.00,
        backgroundColor: Colors.black38,
      ),

      body: Column(
        children: [
          Buttoms(),
          Divider(height: 25,),
          List(),
          Divider(height: 25,),
          ListTwo()
        ],
      ),

      bottomNavigationBar: BottomNavigationBar(
          selectedItemColor: Colors.red,
          unselectedItemColor: Colors.grey,
          showSelectedLabels: true,
          showUnselectedLabels: true,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(
                Icons.home_outlined,
                color: Colors.red,
              ),
              label: "Home",
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Icons.apps_outlined,
                color: Colors.black38,
              ),
              label: "Category",
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Icons.favorite_outline,
                color: Colors.black38,
              ),
              label: "Favorite",
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Icons.settings,
                color: Colors.black38,
              ),
              label: "Setting",
            ),
          ]),
    );
  }

  Widget Buttoms()=>Container(
    decoration: BoxDecoration(
      color: Colors.grey.withOpacity(0.2),
    ),
    padding: const EdgeInsets.all(20.0),
    child: Row(
      children: [
        Column(
          children: [
            MaterialButton(
              height: 80,
              minWidth: 100,
              shape: RoundedRectangleBorder(
                  borderRadius: new BorderRadius.circular(20)),
              onPressed: () {},
              child: Icon(Icons.tune,color: Colors.white,size: 40,),
              color: Colors.red,
            ),
            SizedBox(height: 10,),
            Text("Off Energy"),
          ],
        ),
        SizedBox(width: 20,),
        Column(
          children: [
            MaterialButton(
              height: 80,
              minWidth: 100,
              shape: RoundedRectangleBorder(
                  borderRadius: new BorderRadius.circular(20)),
              onPressed: () {},
              child: Icon(Icons.lock,color: Colors.black38,size: 40,),
              color: Colors.white,
            ),
            SizedBox(height: 10,),
            Text("Left Home"),
          ],
        ),
        SizedBox(width: 20,),
        Column(
          children: [
            MaterialButton(
              height: 80,
              minWidth: 100,
              shape: RoundedRectangleBorder(
                  borderRadius: new BorderRadius.circular(20)),
              onPressed: () {},
              child: Icon(Icons.key,color: Colors.black38,size: 40,),
              color: Colors.white,
            ),
            SizedBox(height: 10,),
            Text("Came Home"),
          ],
        ),
      ],
    ),
  );

  Widget List()=>Container(
    height: 150,
    color: Colors.grey.withOpacity(0.2),
    child: Padding(
      padding: const EdgeInsets.all(1.0),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Row(
              children: [
                Text("My Home",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18),),
                SizedBox(width: 260,),
                Icon(Icons.arrow_forward_ios,color: Colors.black38,)
              ],
            ),
            Divider(),
            Row(
              children: [
                Text("Message",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18),),
                SizedBox(width: 10,),
                Container(
                  height: 30,
                  width: 30,
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(50),
                  ),
                  child: IconButton(onPressed: (){},
                      icon: Text("3",style: TextStyle(color: Colors.white,),),
                  ),
                ),
                SizedBox(width: 220,),
                Icon(Icons.arrow_forward_ios,color: Colors.black38,)
              ],
            ),
            Divider(),
            Row(
              children: [
                Text("Family Acess",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18),),
                SizedBox(width: 230,),
                Icon(Icons.arrow_forward_ios,color: Colors.black38,)
              ],
            ),
          ],
        ),
      ),
    ),
  );

  Widget ListTwo()=>Container(
    height: 100,
    color: Colors.grey.withOpacity(0.2),
    child: Padding(
      padding: const EdgeInsets.all(1.0),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Row(
              children: [
                Text("Change Password",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18),),
                SizedBox(width: 190,),
                Icon(Icons.arrow_forward_ios,color: Colors.black38,)
              ],
            ),
            Divider(),
            Row(
              children: [
                Text("Support",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18),),
                SizedBox(width: 270,),
                Icon(Icons.arrow_forward_ios,color: Colors.black38,)
              ],
            ),

          ],
        ),
      ),
    ),
  );

}
